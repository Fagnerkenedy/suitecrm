<?php
$dashletData['TemplateSectionLineDashlet']['searchFields'] = array(
  'date_entered' =>
  array(
    'default' => '',
  ),
  'date_modified' =>
  array(
    'default' => '',
  ),
  'assigned_user_id' =>
  array(
    'type' => 'assigned_user_name',
    'default' => 'Administrator',
  ),
);
$dashletData['TemplateSectionLineDashlet']['columns'] = array(
  'name' =>
  array(
    'width' => '40%',
    'label' => 'LBL_LIST_NAME',
    'link' => true,
    'default' => true,
    'name' => 'name',
  ),
  'grp' =>
  array(
    'type' => 'varchar',
    'label' => 'LBL_GRP',
    'width' => '10%',
    'default' => true,
  ),
  'description' =>
  array(
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
  ),
);
