<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.20';
$suitecrm_timestamp = '2021-05-28 17:00:00';
